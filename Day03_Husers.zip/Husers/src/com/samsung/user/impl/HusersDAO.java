package com.samsung.user.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.samsung.user.vo.HusersVO;
import com.samsung.util.JDBCUtils;

public class HusersDAO {
	Connection conn = null;
	PreparedStatement stmt = null;
	ResultSet rs = null;
	public void addHusers(HusersVO vo){
		System.out.println("애드 진입");
		try {
			conn = JDBCUtils.getConnection();
			String sql = "insert into husers(seq, name, password, email, age, gender) "
					+ "values( (select nvl(max(seq), 0)+1 from husers), "
					+ "?, ?, ?, ?, ?)";
			stmt = conn.prepareStatement(sql);

			// 4단계 => 쿼리에 들어갈 변수들을 세팅 작업
			// ?에 대한 세팅 작업
			stmt.setString(1, vo.getName());
			stmt.setString(2, vo.getPassword());
			stmt.setString(3, vo.getEmail());
			stmt.setInt(4, vo.getAge());
			stmt.setInt(5, vo.getGender());

			// 5단계 => 쿼리를 실행하고 그 결과값을 받아온다.
			int cnt = stmt.executeUpdate();

			System.out.println(cnt + "개 정상 입력되었습니다.");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(stmt, conn);
		}

	}
	
	public ArrayList<HusersVO> getHusersList(){
		System.out.println("진입");
		ArrayList<HusersVO> list = new ArrayList<>();
		try {
			conn = JDBCUtils.getConnection();
			String sql = "select * from husers order by seq desc";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			HusersVO vo = null;
			while(rs.next()){
				vo = new HusersVO();
				vo.setSeq(rs.getInt("seq"));
				vo.setName(rs.getString("name"));
				vo.setPassword(rs.getString("password"));
				vo.setEmail(rs.getString("email"));
				vo.setAge(rs.getInt("age"));
				vo.setGender(rs.getInt("gender"));
				list.add(vo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCUtils.close(rs, stmt, conn);
		}
		for (int i = 0; i < list.size(); i++) {
			list.get(i).toString();
		}
		return list;
	}

}
