select * from member

drop table member
drop table gul
drop table reply
drop table glike

CREATE TABLE  "MEMBER"(
	"ID" VARCHAR2(20) NOT NULL ENABLE, 
	"PASSWORD" VARCHAR2(20) NOT NULL ENABLE, 
	"NICKNAME" VARCHAR2(50) NOT NULL ENABLE, 
	"BIRTH" DATE NOT NULL ENABLE, 
	 CONSTRAINT "MEMBER_PK" PRIMARY KEY ("ID") ENABLE
)

CREATE TABLE  "GUL" 
   (	"GSEQ" NUMBER(3,0) NOT NULL ENABLE, 
	"ID" VARCHAR2(20) NOT NULL ENABLE, 
	"PIC" VARCHAR2(200) NOT NULL ENABLE, 
	"GCONTENT" VARCHAR2(1000) NOT NULL ENABLE, 
	"LIKECNT" NUMBER(3,0) NOT NULL ENABLE, 
	"GDATE" DATE NOT NULL ENABLE, 
	 CONSTRAINT "GUL_PK" PRIMARY KEY ("GSEQ") ENABLE, 
	 CONSTRAINT "GUL_FK" FOREIGN KEY ("ID")
	  REFERENCES  "MEMBER" ("ID") ENABLE
   );

CREATE TABLE  "REPLY"(
	"RSEQ" NUMBER(3,0), 
	"ID" VARCHAR2(20), 
	"GSEQ" NUMBER(3,0), 
	"RCONTENT" VARCHAR2(500), 
	"RDATE" DATE, 
	 CONSTRAINT "REPLY_PK" PRIMARY KEY ("RSEQ") ENABLE, 
	 CONSTRAINT "REPLY_FK" FOREIGN KEY ("ID")
	  REFERENCES  "MEMBER" ("ID") ENABLE, 
	 CONSTRAINT "REPLY_FK2" FOREIGN KEY ("GSEQ")
	  REFERENCES  "GUL" ("GSEQ") ENABLE
)

CREATE TABLE  "GLIKE"(
	"LSEQ" NUMBER(3,0), 
	"GSEQ" NUMBER(3,0), 
	"ID" VARCHAR2(20), 
	 CONSTRAINT "GLIKE_PK" PRIMARY KEY ("LSEQ") ENABLE, 
	 CONSTRAINT "GLIKE_FK" FOREIGN KEY ("GSEQ")
	  REFERENCES  "GUL" ("GSEQ") ENABLE, 
	 CONSTRAINT "GLIKE_FK2" FOREIGN KEY ("ID")
	  REFERENCES  "MEMBER" ("ID") ENABLE
)

select lag(gseq,1), lag(id,1), lag(pic,1), lag(gcontent,1), lag(likecnt,1), lag(gdate,1)
from gul
where gseq=3

select gseq 현재글, lead(gseq,1) over (order by gseq) next_시퀀,
		lag(gseq,1) over (order by gseq ) pre_시퀀
from gul 
where gseq=4

select * 
from (select gseq aa, lead(gseq,1) over (order by gseq) next_시퀀,
		lag(gseq,1) over (order by gseq ) pre_시퀀
	  from gul
	)
where aa=4

select bb 
from (select gseq aa, lag(gseq,1) over (order by gseq ) bb
	  from gul
	)
where aa=4

select * 
from (select lead(gseq,1) over (order by gseq ) aa from gul)
where aa=2

select * from gul
select * from member

delete from gul;

delete from gul where gseq = 4;
delete from gul where gseq = 5;

insert into gul values((select nvl(max(gseq),0)+1 from gul), 'user01', 'test','테스트', 0, sysdate);
insert into gul values((select nvl(max(gseq),0)+1 from gul), 'user01', 'test2','테스트2', 0, sysdate);
insert into gul values((select nvl(max(gseq),0)+1 from gul), 'user01', 'test3','테스트3', 0, sysdate);
insert into gul values((select nvl(max(gseq),0)+1 from gul), 'user01', 'test4','테스트4', 0, sysdate);

		select b.* 
		from ( select rownum ro, a.* 
			   from (select gseq, id, pic, gcontent, likecnt, gdate 
					  from gul 
					  order by gseq desc 
					 ) a 
			  ) b 
		where ro >= 3 and ro <= 4 	  

select * from glike
select * from gul where gseq=10
select * from reply
select * from reply where gseq=9
select * from member

update gul set gcontent='소녀시대 슈퍼주니어 샤이니 EXO 에프엑스' where gseq=11

insert into member values('user02', 123, 'test02', sysdate);
insert into member values('user03', 123, 'test02', sysdate);
insert into member values('userte', 123, 'test02', sysdate);
