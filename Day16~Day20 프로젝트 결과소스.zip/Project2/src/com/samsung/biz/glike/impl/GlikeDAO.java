package com.samsung.biz.glike.impl;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.samsung.biz.glike.vo.GlikeVO;

@Repository("glikeDAO")
public class GlikeDAO {
	
	@Autowired
	@Qualifier("sqlSession")
	private SqlSession myBatis = null;
	
	public void insertGlike(GlikeVO vo){
		System.out.println(vo);
		myBatis.insert("insertGlike", vo);
	}
	
	public void deleteGlike(GlikeVO vo){
		myBatis.delete("deleteGlike", vo);
	}

}
