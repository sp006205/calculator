package com.samsung.biz.glike.vo;

import org.springframework.stereotype.Component;

@Component("glikeVO")
public class GlikeVO {
	private int lseq;
	private int gseq;
	private String id;

	public int getLseq() {
		return lseq;
	}

	public void setLseq(int lseq) {
		this.lseq = lseq;
	}

	public int getGseq() {
		return gseq;
	}

	public void setGseq(int gseq) {
		this.gseq = gseq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Glike [lseq=" + lseq + ", gseq=" + gseq + ", id=" + id + "]";
	}
}
