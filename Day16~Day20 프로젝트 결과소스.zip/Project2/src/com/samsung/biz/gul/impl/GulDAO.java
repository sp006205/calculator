package com.samsung.biz.gul.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.samsung.biz.gul.vo.GulVO;

@Repository("gulDAO")
public class GulDAO {
	
	@Autowired
	@Qualifier("sqlSession")
	private SqlSession myBatis;

	public ArrayList<GulVO> getGulList() {
		
		ArrayList<GulVO> gulList = (ArrayList) myBatis.selectList("getGulList");
		for(GulVO g:gulList){
			System.out.println(g);
		}
		return gulList;
	}

	public void addGul(GulVO vo) {
		myBatis.insert("insertGul", vo);		
	}

	public GulVO getGul(int gseq) {
		GulVO vo = myBatis.selectOne("selectGul", gseq);
		return vo;
	}

	public int getPrevGul(int gseq) {
		int newGseq = myBatis.selectOne("selectPrevGul", gseq);
		return newGseq;
	}
	
	public int getNextGul(int gseq) {
		int newGseq = myBatis.selectOne("selectNextGul", gseq);
		return newGseq;
	}

	public void updateLikeCnt(GulVO vo) {
		int su = myBatis.update("updateLikeCnt", vo);
	}
	
	public int listCount() {
		int count = myBatis.selectOne("selectListCount");
		return count;
	}

	/**
	 * 상품 목록 조회를 위한 메소드 => 페이지 처리
	 * 
	 * @param page     페이지 번호
	 * @param interval 한 페이지에 보여줄 상품 개수 
	 * @return ArrayList<Product> : Product을 원소로하는 리스트를 반환한다.
	 */
	public ArrayList<GulVO> list(int page, int interval){
		//List<Object> list = new ArrayList<GulVO>();
		Map<String, Integer> map = new HashMap<>();
		int start = 1; // 한페이지에 보여줄 게시글 시작 번호
		int end = interval; // 한페이지에 보여줄 게시글 마직막 번호
		// 페이지에 따른 글번호 계산
		if (page > 1) {
			start = (page - 1) * interval + 1;
			//end = start + interval - 1;
			end = page * interval;
		}
		map.put("start", start);
		map.put("end", end);
		int su = 1;
		ArrayList<GulVO> list = (ArrayList)myBatis.selectList("selectGulListByPage", map);
		return list;
	}

	public void updateLikeCntForMinus(GulVO gul) {
		myBatis.update("updateLikeCntForMinus", gul);

		
	}	


	
	

}
