package com.samsung.biz.gul.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;
@Component("gulVO")
public class GulVO {
	private int gseq;
	private String id;
	private String pic;
	private String gcontent;
	private int likecnt;
	private Date gdate;
	public int getGseq() {
		return gseq;
	}
	public void setGseq(int gseq) {
		this.gseq = gseq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getGcontent() {
		return gcontent;
	}
	public void setGcontent(String gcontent) {
		this.gcontent = gcontent;
	}
	public int getLikecnt() {
		return likecnt;
	}
	public void setLikecnt(int likecnt) {
		this.likecnt = likecnt;
	}
	public Date getGdate() {
		return gdate;
	}
	public void setGdate(Date gdate) {
		this.gdate = gdate;
	}
	
	@Override
	public String toString() {
		return "GulVO [gseq=" + gseq + ", id=" + id + ", pic=" + pic
				+ ", gcontent=" + gcontent + ", likenum=" + likecnt
				+ ", gdate=" + gdate + "]";
	}
	
//	CREATE TABLE  "GLIKE"(
//			"LSEQ" NUMBER(3,0), 
//			"GSEQ" NUMBER(3,0), 
//			"ID" VARCHAR2(20), 
//			 CONSTRAINT "GLIKE_PK" PRIMARY KEY ("LSEQ") ENABLE, 
//			 CONSTRAINT "GLIKE_FK" FOREIGN KEY ("GSEQ")
//			  REFERENCES  "GUL" ("GSEQ") ENABLE, 
//			 CONSTRAINT "GLIKE_FK2" FOREIGN KEY ("ID")
//			  REFERENCES  "MEMBER" ("ID") ENABLE
//		)
//
	
}
