package com.samsung.biz.member.impl;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.samsung.biz.member.vo.MemberVO;

@Repository("memberDAO")
public class MemberDAO {
	
	@Autowired
	@Qualifier("sqlSession")
	private SqlSession myBatis = null;
	
	public MemberVO login(MemberVO vo) {
		System.out.println("MemberDAO > login()");
		MemberVO member = myBatis.selectOne("getMember", vo);
		return member;
	}
	
	/*public void logout(MemberVO vo) {

	}*/
	
	public void join(MemberVO vo) {
		System.out.println("MemberDAO > join()");
		myBatis.insert("join", vo);
	}
	
	public void editMember(MemberVO vo) {
		System.out.println("MemberDAO > editMember()");
		myBatis.update("editMember", vo);
	}
	
	public void deleteMember(MemberVO vo) {
		System.out.println("MemberDAO > deleteMember()");
		myBatis.delete("deleteMember", vo);
	}
}
