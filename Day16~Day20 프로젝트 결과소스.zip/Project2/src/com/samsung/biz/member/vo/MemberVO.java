package com.samsung.biz.member.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;
@Component("memberVO")
public class MemberVO {
	private String id;
	private String password;
	private String nickname;
	private Date birth;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public Date getBirth() {
		return birth;
	}
	public void setBirth(Date birth) {
		this.birth = birth;
	}
	@Override
	public String toString() {
		return "MemberVO [id=" + id + ", password=" + password + ", nickname="
				+ nickname + ", birth=" + birth + "]";
	}
}
