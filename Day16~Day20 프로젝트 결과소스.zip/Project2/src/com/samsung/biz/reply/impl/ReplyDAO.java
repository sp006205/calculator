package com.samsung.biz.reply.impl;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.samsung.biz.gul.vo.GulVO;
import com.samsung.biz.reply.vo.ReplyVO;

@Repository("replyDAO")
public class ReplyDAO {
	
	@Autowired
	@Qualifier("sqlSession")
	private SqlSession myBatis;

	public void updateReply(ReplyVO vo) {
		myBatis.update("updateReply", vo);
	}
	
	public void deleteReply(ReplyVO vo) {
		myBatis.delete("deleteReply", vo);
	}
	
	public void insertReply(ReplyVO vo) {
		myBatis.insert("insertReply", vo);
	}
	
	public ReplyVO getReply(ReplyVO vo) {
		myBatis.selectOne("selectReply", vo);
		return vo;
	}
	public ArrayList<ReplyVO> getReplyList(GulVO vo) {
		ArrayList<ReplyVO> list = new ArrayList<>();
		if ((ArrayList)myBatis.selectList("selectReplyList", vo) != null) {
			list = (ArrayList)myBatis.selectList("selectReplyList", vo);
			return list;
		} else {
			return null;
		}
	}

}
