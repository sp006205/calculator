package com.samsung.biz.reply.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;
@Component("replyVO")
public class ReplyVO {
	private int rseq;
	private String id;
	private int gseq;
	private String rcontent;
	private Date rdate;
	public int getRseq() {
		return rseq;
	}
	public void setRseq(int rseq) {
		this.rseq = rseq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getGseq() {
		return gseq;
	}
	public void setGseq(int gseq) {
		this.gseq = gseq;
	}
	public Date getRdate() {
		return rdate;
	}
	public void setRdate(Date rdate) {
		this.rdate = rdate;
	}
	public String getRcontent() {
		return rcontent;
	}
	public void setRcontent(String rcontent) {
		this.rcontent = rcontent;
	}
	@Override
	public String toString() {
		return "Reply [rseq=" + rseq + ", id=" + id + ", gseq=" + gseq
				+ ", rcontent=" + rcontent + ", rdate=" + rdate + "]";
	}
	
	
}
