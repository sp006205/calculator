package com.samsung.view.glike;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.samsung.biz.glike.impl.GlikeDAO;
import com.samsung.biz.glike.vo.GlikeVO;
import com.samsung.biz.gul.impl.GulDAO;
import com.samsung.biz.gul.vo.GulVO;

@Controller
public class GlikeController {
	
	@Autowired
	private GlikeDAO dao;
	
	@Autowired
	private GulDAO gdao;
	
	@RequestMapping("/insertLikeCnt.do")
	@ResponseBody
	public HashMap<String, Object> addGlike(GlikeVO vo, HttpSession session, GulVO gul) {
		//vo.setId((String)session.getAttribute("id"));
		HashMap<String, Object> map = new HashMap<>();
		vo.setId("user02");
		dao.insertGlike(vo);
		gul = gdao.getGul(vo.getGseq());
		System.out.println("인서트: "+gul);
		System.out.println("비뽀"+gul.getLikecnt());
		gdao.updateLikeCnt(gul);
		gul = gdao.getGul(vo.getGseq());
		map.put("gseq", vo.getGseq());
		map.put("likecnt", gul.getLikecnt());
		System.out.println("sadf"+map.get("gseq"));
		System.out.println("애쁘터"+gul.getLikecnt());
		session.setAttribute("like", "yes");
		return map;
	}
	
	@RequestMapping("/deleteLikeCnt.do")
	@ResponseBody
	public HashMap<String, Object> deleteGlike(GlikeVO vo, HttpSession session) {
		//vo.setId((String)session.getAttribute("id"));
		HashMap<String, Object> map = new HashMap<>();
		GulVO gul = gdao.getGul(vo.getGseq());
		System.out.println("딜리트: "+gul);
		vo.setId("user02");
		dao.deleteGlike(vo);
		System.out.println("딜리트 비뽀"+gul.getLikecnt());
		gdao.updateLikeCntForMinus(gul);
		gul = gdao.getGul(vo.getGseq());
		map.put("gseq", vo.getGseq());
		map.put("likecnt", gul.getLikecnt());
		System.out.println("sadf"+map.get("gseq"));
		System.out.println("딜리트 애쁘터"+map.get("likecnt"));
		session.setAttribute("like", "no");
		return map;
	}
	



}
