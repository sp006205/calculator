package com.samsung.view.gul;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.samsung.biz.common.AdvancedPageUtility;
import com.samsung.biz.gul.impl.GulDAO;
import com.samsung.biz.gul.vo.GulVO;
import com.samsung.biz.reply.impl.ReplyDAO;
import com.samsung.biz.reply.vo.ReplyVO;

@Controller
public class GulController {
	
	@Autowired
	@Qualifier("gulDAO")
	private GulDAO dao;
	
	@Autowired
	private ReplyDAO rdao;
	
	@RequestMapping("/getGulList.do")
	public String getGulList(GulVO vo, ArrayList<GulVO> list, Model md, HttpServletRequest request) {
		/////////////////////////////////////////////////////////////
		String cpage;
		if(request.getParameter("pageNo") != null){
			cpage = request.getParameter("pageNo");
		}else {
			cpage = "1";
		}
		int page = 1;
		if(cpage != null ){
			page = Integer.parseInt(cpage);
		}
		int interval = 6;  //한 페이지에 보여줄 상품 개수
		list = dao.list(page, interval);
		int total = dao.listCount();
		total = total==0 ? 1:total;
			
		AdvancedPageUtility bar = null;
		try {
			bar = new AdvancedPageUtility(interval, total, page, "images/");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		md.addAttribute("pageLink", bar.getPageBar());
		md.addAttribute("list", list);
		return "getGulList.jsp";
		/////////////////////////////////////////////////////////////
//		list = dao.getGulList();
//		md.addAttribute("list", list);
//		return "getGulList.jsp";
	}
	
	@RequestMapping("/addGul.do")
	public String addGul(HttpServletRequest request, HttpServletResponse response) {
		//String saveDir = "images";
		/*String saveFullDir = request.getServletContext().getRealPath(saveDir);*/
		String saveFullDir = "C://javaWorks/Project2/WebContent/images";
		int maxFileSize = 5*1024*1024;
		String encoding = "utf-8";
		System.out.println("룰루랄라"+saveFullDir);

		MultipartRequest mRequest = null;
		String pic = "";
		GulVO vo = new GulVO();
		try {
			mRequest = new MultipartRequest(request,saveFullDir,maxFileSize,encoding,		
					new DefaultFileRenamePolicy());
			pic = mRequest.getFilesystemName("img");
			String id = mRequest.getParameter("id");
			String gcontent = mRequest.getParameter("gcontent");
			vo.setPic(pic);
			vo.setGcontent(gcontent);
			vo.setId(id);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(vo);
		dao.addGul(vo);
		return "getGulList.do";
	}
	
	@RequestMapping("/getGul.do")
	public String getGul(Model md, GulVO vo){
		GulVO gul = dao.getGul(vo.getGseq());
		ArrayList<ReplyVO> list = new ArrayList<>();
		list = rdao.getReplyList(vo);
		for (ReplyVO replyVO : list) {
			System.out.println(replyVO);
		}
		md.addAttribute("gul", gul);
		md.addAttribute("reply", list);
		
		return "getGul.jsp";
	}
	
	@RequestMapping("/getPrevGul.do")
	public String getPrevGul(GulVO vo, Model md, HttpServletRequest request){
		System.out.println("이전글 컨트롤러 진입");
		int newGseq;
		try {
			newGseq = dao.getPrevGul(vo.getGseq());
		} catch (NullPointerException e) {
			newGseq = dao.listCount();
		}
		vo.setGseq(newGseq);
		GulVO gul = dao.getGul(vo.getGseq());
		md.addAttribute("gul", gul);
		ArrayList<ReplyVO> list = new ArrayList<>();
		list = rdao.getReplyList(vo);
//		for (ReplyVO replyVO : list) {
//			System.out.println(replyVO);
//		}
		md.addAttribute("reply", list);

		return "getGul.jsp";
	}
	
	@RequestMapping("/getNextGul.do")
	public String getNextGul(GulVO vo, Model md, HttpServletRequest request){
		
		int newGseq;
		try {
			newGseq = dao.getNextGul(vo.getGseq());
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			newGseq = 1;
		}
		vo.setGseq(newGseq);
		GulVO gul = dao.getGul(vo.getGseq());
		md.addAttribute("gul", gul);
		ArrayList<ReplyVO> list = new ArrayList<>();
		list = rdao.getReplyList(vo);
//		for (ReplyVO replyVO : list) {
//			System.out.println(replyVO);
//		}
		md.addAttribute("reply", list);

		return "getGul.jsp";
	}
	
	@RequestMapping("/updateLikeCnt.do")
	@ResponseBody
	public HashMap<String, Integer> updateLikeCnt(GulVO vo){
		dao.updateLikeCnt(vo);
		vo = dao.getGul(vo.getGseq());
		HashMap map = new HashMap<>();
		map.put("gseq", vo.getGseq());
		map.put("likecnt", vo.getLikecnt());
		return map;
	}
	
	@RequestMapping("/getGulPage.do")
	private String getGulPage(GulVO vo, @RequestParam("pageNo") String cpage,
								GulDAO dao, Model md){
			System.out.println(cpage);
			ArrayList<GulVO> list = null; 
			int page = 1;
			if(cpage != null ){
				page = Integer.parseInt(cpage);
			}
			int interval = 3;  //한 페이지에 보여줄 상품 개수
			list = dao.list(page, interval);
			int total = dao.listCount();
			total = total==0 ? 1:total;
				
			AdvancedPageUtility bar = null;
			try {
				bar = new AdvancedPageUtility(interval, total, page,"images/");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			md.addAttribute("pageLink", bar.getPageBar());
			md.addAttribute("board", list);
			return "getGulList.jsp";
	}
	
	@RequestMapping("/getGulForFirst.do")
	private String getGulByRandom(Model md, GulVO vo){
		int size = dao.listCount();
		
		int su = (int) (Math.random() * size);
		vo = dao.getGul(su);
		md.addAttribute("gul", vo);
		return "getGul.jsp";
	}


}
