package com.samsung.view.member;

import java.sql.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.samsung.biz.member.impl.MemberDAO;
import com.samsung.biz.member.vo.MemberVO;

@Controller
public class MemberController {
	
	@Autowired
	@Qualifier("memberDAO")
	private MemberDAO dao;
	
	@RequestMapping(method = RequestMethod.POST, value = "/login.do")
	@ResponseBody
	public String login(MemberVO vo, HttpSession session) {
		System.out.println("아이디: "+vo.getId()+" , 패스워드: "+vo.getPassword());
		if (vo.getId().equals("") || vo.getPassword().equals("")) {
			System.out.println("리턴 널");
			return "login null";
		}
		System.out.println("MemberController > login(vo, session)");
		MemberVO member = dao.login(vo);
		if (member != null) {
			session.setAttribute("id", member.getId());
			session.setAttribute("nickname", member.getNickname());
			//System.out.println(member.getBirth());
			session.setAttribute("birthday", member.getBirth());
			System.out.println("리턴 성공");
			return "login success";
		} else {
			//System.out.println("===login===");
			System.out.println("리턴 실패");
			return "login wrong";
		}
	}
	
	@RequestMapping("/logout.do")
	public String logout(HttpSession session) {

		session.invalidate();
		System.out.println("===logout===");
		return "login.jsp";
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/join.do")
	@ResponseBody
	public String join(
			@RequestParam("birthday") String birthday,
			MemberVO vo, HttpSession session) {
		System.out.println("MemberController > join()");
		if (vo.getId().equals("") || vo.getNickname().equals("")
				|| vo.getPassword().equals("") || birthday.equals("")) {
			return "join null";
		}
		vo.setBirth(Date.valueOf(birthday));
		
		dao.join(vo);
		return "join success";
	}
	
	@RequestMapping(method = RequestMethod.POST, value = "/editMember.do")
	@ResponseBody
	public String editMember(MemberVO vo, HttpSession session){
		System.out.println("MemberController > editMember()");
		
		String id = (String) session.getAttribute("id");
		if (id == null){
			return "login.jsp";
		}
		
		if (vo.getNickname().equals("") || vo.getPassword().equals("")) {
			return "editMember null";
		}
		dao.editMember(vo);
		return "editMember success";
	}
	
	@RequestMapping("/deleteMember.do")
	public String deleteMember(MemberVO vo, HttpSession session){
		System.out.println("MemberController > deleteMember()");
		
		String id = (String) session.getAttribute("id");
		if (id == null){
			return "login.jsp";
		}
		System.out.println(id);
		vo.setId(id);
		dao.deleteMember(vo);
		return "logout.do";
	}
}
