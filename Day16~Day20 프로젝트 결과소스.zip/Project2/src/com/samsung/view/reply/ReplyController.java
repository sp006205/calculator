package com.samsung.view.reply;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.samsung.biz.gul.impl.GulDAO;
import com.samsung.biz.gul.vo.GulVO;
import com.samsung.biz.reply.impl.ReplyDAO;
import com.samsung.biz.reply.vo.ReplyVO;

@Controller
public class ReplyController {
	
	@Autowired
	private ReplyDAO dao;
	
	@Autowired
	private GulDAO gdao;
	
	
	
	@RequestMapping("/insertReply.do")
	@ResponseBody
	public ReplyVO insertReply(ReplyVO vo, Model md){
		vo.setId("user01");		//이거 나중에 세션으로...ㅣ!!
		System.out.println(vo);
		
		dao.insertReply(vo);
		md.addAttribute("reply", vo);
		return vo;
	}
	
	@RequestMapping("/deleteReply.do")
	public String deleteReply(ReplyVO vo, GulVO gul, Model md){
		gul = gdao.getGul(vo.getGseq());
		dao.deleteReply(vo);
		ArrayList<ReplyVO> list = new ArrayList<>();
		System.out.println("글입니다."+gul);
		list = dao.getReplyList(gul);
		md.addAttribute("gul", gul);
		md.addAttribute("reply", list);
		return "getGul.jsp";
	}

}
