package com.samsung.biz.gul;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.samsung.biz.gul.impl.GulDAO;
import com.samsung.biz.gul.vo.GulVO;

public class GetGulList {
	public static void main(String[] args) {
		
		ApplicationContext factory = new ClassPathXmlApplicationContext("applicationContext.xml");

		GulVO vo = (GulVO)factory.getBean("gulVO");
		GulDAO dao = (GulDAO)factory.getBean("gulDAO");
		
		ArrayList<GulVO> list = new ArrayList<>();
		list = dao.getGulList();
		for (GulVO gulVO : list) {
			System.out.println(gulVO);
		}
	}

}
